namespace LoyaltyApp.Models;

public enum ActionType
{
    CreateUser,
    ChageUserRole,
    CreateCustomer,
    EditCustomer,
    IncreaseBalance,
    WithdrawBalance,
}