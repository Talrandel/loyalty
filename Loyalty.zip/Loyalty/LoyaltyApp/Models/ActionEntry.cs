namespace LoyaltyApp.Models;

public class ActionEntry
{
    
}